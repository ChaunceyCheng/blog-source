package com.yihengliu.springboottest.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 测试controller
 * 
 * @author liucheng
 **/
@RestController
public class TestController {
	@RequestMapping("/index")
	public String method() {
		return "return request";
	}
}
