package com.yihengliu.angularjsdemo.model;

/**
 * 用户类
 *
 * @author liucheng
 * @version 0.1
 * @since 0.1 2018-01-22 下午3:28
 **/
public class User {
    private Integer Id;
    private String name;
    private String password;

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}