package com.yihengliu.angularjsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularjsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngularjsDemoApplication.class, args);
	}
}
