package com.yihengliu.angularjsdemo.dao;

import com.yihengliu.angularjsdemo.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 用户Dao类
 *
 * @author liucheng
 * @version 0.1
 * @since 0.1 2018-01-22 下午3:29
 **/
@Repository
public class UserDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM t_user";
        SqlRowSet rows = jdbcTemplate.queryForRowSet(sql, new Object[]{});
        while (rows.next()) {
            User user = new User();
            user.setId(rows.getInt("id"));
            user.setName(rows.getString("name"));
            user.setPassword(rows.getString("password"));
            list.add(user);
        }
        return list;
    }

    public User get(String id) {
        User user = null;
        String sql = "SELECT * FROM t_user WHERE ID = ?";
        SqlRowSet rows = jdbcTemplate.queryForRowSet(sql, new Object[]{id});
        while (rows.next()) {
            user = new User();
            user.setId(rows.getInt("id"));
            user.setName(rows.getString("name"));
            user.setPassword(rows.getString("password"));
        }
        return user;
    }

    public Integer insert(User user) {
        String sql = "INSERT INTO t_user (name, password) VALUE (?, ?)";
        Map<String, Object> tableStatus = jdbcTemplate.queryForMap("SHOW TABLE STATUS WHERE NAME='T_USER';");
        jdbcTemplate.update(sql, new Object[]{user.getName(), user.getPassword()});
        BigInteger id = (BigInteger) tableStatus.get("Auto_increment");
        return id.intValue();
    }

    public void update(User user) {
        String sql = "UPDATE t_user SET NAME = ?, PASSWORD = ? WHERE ID = ?";
        jdbcTemplate.update(sql, new Object[]{user.getName(), user.getPassword(), user.getId()});
    }

    public void delete(String id) {
        String sql = "DELETE FROM t_user WHERE ID = ?";
        jdbcTemplate.update(sql, new Object[]{id});
    }
}