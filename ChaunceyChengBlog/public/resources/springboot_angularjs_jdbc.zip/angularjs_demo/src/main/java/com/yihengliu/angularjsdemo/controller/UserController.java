package com.yihengliu.angularjsdemo.controller;

import com.yihengliu.angularjsdemo.dao.UserDao;
import com.yihengliu.angularjsdemo.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用户controller类
 *
 * @author liucheng
 * @version 0.1
 * @since 0.1 2018-01-22 下午3:34
 **/
@Controller
public class UserController {
    @Autowired
    private UserDao userDao;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @PostMapping("/save")
    @ResponseBody
    public Map<String, Object> save(@RequestBody User user) {
        Map<String, Object> result = new HashMap<>(5);
        if (user.getId() == null) {
            user.setId(userDao.insert(user));
        } else {
            userDao.update(user);
        }
        result.put("id", user.getId());
        return result;
    }

    @PostMapping("/get")
    @ResponseBody
    public User get(String id) {
       return userDao.get(id);
    }

    @ResponseBody
    @RequestMapping("/findAll")
    public List<User> findAll() {
        return userDao.findAll();
    }

    @PostMapping("/delete")
    @ResponseBody
    public Map<String, Object> delete(String id) {
        Map<String, Object> result = new HashMap<>(2);
        userDao.delete(id);
        result.put("id", id);
        return result;
    }
}